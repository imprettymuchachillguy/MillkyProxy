# v9.0.0

- The first release of Nebula V9! And with it bring a whole host of changes:
  - More stable the V8
  - Adds a Marketplace where users can create their own themes & plugins
  - Switches to Astro for speed
  - Other general bug fixes

# v9.0.1

- Bumps dependencies
- Fixes bugs

# 9.0.2

- Adds the ability for a custom wisp server back
- Increases upload fileSize capacity in hopes that bigger files can now be uploaded
