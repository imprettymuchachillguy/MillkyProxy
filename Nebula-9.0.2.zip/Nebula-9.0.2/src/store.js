import { atom } from "nanostores";

export const isMobileNavOpen = atom(false);
