<!-- Legit just so we can use $destroy() -->
<slot />
