declare module "@rubynetwork/rammerhead/src/server/index.js";
